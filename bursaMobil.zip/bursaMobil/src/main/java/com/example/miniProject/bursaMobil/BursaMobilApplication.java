package com.example.miniProject.bursaMobil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BursaMobilApplication {

	public static void main(String[] args) {
		SpringApplication.run(BursaMobilApplication.class, args);
	}

}
